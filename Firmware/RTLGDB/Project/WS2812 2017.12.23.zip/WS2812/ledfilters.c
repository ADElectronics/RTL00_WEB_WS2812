#include "ledfilters.h"

extern uint32_t cfg_updated;

#pragma region ������� ������� �� ������ � ���������

int32_t ledFilter_Init(strip_handler_t *strip, ws2812_t *ws2812)
{
    if(strip->check != LEDFILTERS_CFG_CHECKWORD)
	{
        memset(strip, 0xff, sizeof(strip_handler_t));
        strip->check = LEDFILTERS_CFG_CHECKWORD;
        strip->strip_len = DEF_STRIP_LEN;
        strip->delay = 10;
        strip->brightness = MAX_STRIP_BRIGHT;

        cfg_updated = 1;
    }

    if(strip->strip_len > MAX_STRIP_LEN)
	{
        strip->strip_len = MAX_STRIP_LEN;
        cfg_updated = 1;
    }

    if(strip->delay > MAX_STRIP_DELAY)
	{
        strip->delay = MAX_STRIP_DELAY;
        cfg_updated = 1;
    }

    if(strip->brightness > MAX_STRIP_BRIGHT)
	{
        strip->brightness = MAX_STRIP_BRIGHT;
        cfg_updated = 1;
    }

    strip->hsv_vals = malloc(sizeof(ws2812_hsv_t) * strip->strip_len);
	if (strip->hsv_vals == NULL)
	{
		printf("[%s] malloc() failed\n", __func__);
		return -1;
	}

	memset(strip->hsv_vals, 0x0, sizeof(ws2812_hsv_t) * strip->strip_len);

	ws2812_SetLen(ws2812, strip->strip_len);
	
	return 1;
}

void ledFilter_SetDefualtValue(strip_handler_t *strip, uint8_t val)
{
	uint32_t i;
	for (i = 0; i < strip->strip_len; i++)
	{
		strip->hsv_vals[i].value = val;
	}
}

#pragma endregion

#pragma region Rainbow

void ledFilter_InitRainbow(ctx_rainbow_t *ctx)
{
	if (ctx->valid != LEDFILTERS_CFG_CHECKWORD)
	{
		ctx->valid = LEDFILTERS_CFG_CHECKWORD;
		ctx->hue_min = 0;
		ctx->hue_max = 255;
		ctx->hue_steps = WS2812_LEDS_MAX / 2; // �� ������� ����������� �������� ��� ������
		ctx->cycle_steps = 255;
		ctx->enabled = 1;
		cfg_updated = 1;
	}

	if (ctx->hue_max <= ctx->hue_min)
	{
		ctx->hue_max = ctx->hue_min;
		ctx->hue_step = 0;
		ctx->cycle_step = 0;
		cfg_updated = 1;
	}

	ctx->hue_min = scale_up(ctx->hue_min);
	ctx->hue_max = scale_up(ctx->hue_max);
	
	if (ctx->hue_min != ctx->hue_max)
	{
		if (ctx->hue_steps > 0)
		{
			ctx->hue_step = (ctx->hue_max - ctx->hue_min) / ctx->hue_steps;
		}
		
		if (ctx->cycle_steps > 0)
		{
			ctx->cycle_step = (ctx->hue_max - ctx->hue_min) / ctx->cycle_steps;
		}
	}
	
	ctx->curr_hue = min(ctx->curr_hue, ctx->hue_max);
	ctx->curr_hue = max(ctx->curr_hue, ctx->hue_min);
}

void ledFilter_Rainbow(ctx_rainbow_t *ctx, strip_handler_t *strip)
{
	uint32_t i;
	ws2812_hsv_t tmp_hsv;
	uint32_t tmp_hue;

	if (ctx->enabled == 0) return;

	tmp_hue = ctx->curr_hue;
	tmp_hsv.sat = 255;
	//tmp_hsv.value = MAX_STRIP_BRIGHT;

	for (i = 0; i < strip->strip_len; i++)
	{
		tmp_hsv.hue = scale_down(tmp_hue);
		tmp_hsv.value = strip->hsv_vals[i].value;
		strip->hsv_vals[i] = tmp_hsv;

		tmp_hue += ctx->hue_step;
		if (ctx->hue_min == 0 && ctx->hue_max == scale_up(255u))
		{
			tmp_hue %= scale_up(256);
		}
		else
		{
			if (tmp_hue > ctx->hue_max)
			{
				tmp_hue = ctx->hue_max;
				ctx->hue_step = -ctx->hue_step;
			}
			else if (tmp_hue < ctx->hue_min)
			{
				tmp_hue = ctx->hue_min;
				ctx->hue_step = -ctx->hue_step;
			}
		}
	}

	ctx->curr_hue += ctx->cycle_step;
	if (ctx->hue_min == 0 && ctx->hue_max == scale_up(255u))
	{
		ctx->curr_hue %= scale_up(256);
	}
	else
	{
		if (ctx->curr_hue > ctx->hue_max)
		{
			ctx->curr_hue = ctx->hue_max;
			ctx->cycle_step = -ctx->cycle_step;
		}
		else if (ctx->curr_hue < ctx->hue_min)
		{
			ctx->curr_hue = ctx->hue_min;
			ctx->cycle_step = -ctx->cycle_step;
		}
	}
}
#pragma endregion

#pragma region Fade

void ledFilter_InitFade(ctx_fade_t *ctx)
{
	if (ctx->valid != LEDFILTERS_CFG_CHECKWORD)
	{
		ctx->valid = 1;
		ctx->min = 0;
		ctx->max = 255;
		ctx->steps = LEDFILTERS_MAX_STEPS;
		ctx->enabled = 1;
		cfg_updated = 1;
	}

	if (ctx->min >= ctx->max)
	{
		ctx->max = ctx->min;
		cfg_updated = 1;
	}

	if (ctx->steps > 0)
	{/*
		if (ctx->curr_step < 0)
		{
			ctx->curr_step = -(int32_t)((ctx->max - ctx->min) / cfg->fade.steps);
		}
		else
		{
			ctx->curr_step = (ctx->max - ctx->min) / cfg->fade.steps;
		}*/
	}
	else
	{
		ctx->enabled = 0;

	}

	ctx->curr_val = 0;
	ctx->curr_step = 0;
}

void ledFilter_Fade(ctx_fade_t *ctx, strip_handler_t *strip)
{
	uint32_t i;

	if (ctx->enabled == 0) return;

	if (ctx->curr_val == 0)
	{
		for (i = 0; i < strip->strip_len; i++)
		{
			if (strip->hsv_vals[i].value > ctx->min)
			{
				if (strip->hsv_vals[i].value > (255 / ctx->steps))
					strip->hsv_vals[i].value -= (255 / ctx->steps);
				else
				{
					strip->hsv_vals[i].value = 0;
					ctx->curr_step = ctx->steps;
				}
			}
			else
			{
				ctx->curr_step = ctx->steps;
			}			
		}
	}
	else
	{
		for (i = 0; i < strip->strip_len; i++)
		{
			if (strip->hsv_vals[i].value <= ctx->max)
			{
				if (strip->hsv_vals[i].value + (255 / ctx->steps) > ctx->max)
				{
					strip->hsv_vals[i].value = ctx->max;
					ctx->curr_step = ctx->steps;
				}					
				else
					strip->hsv_vals[i].value += (255 / ctx->steps);
			}
			else
			{
				ctx->curr_step = ctx->steps;
			}
		}
	}
	ctx->curr_step++;

	if (ctx->curr_step >= ctx->steps)
	{
		if (ctx->curr_val) ctx->curr_val = 0;
		else ctx->curr_val = 1;
		ctx->curr_step = 0;
	}
}

#pragma endregion
