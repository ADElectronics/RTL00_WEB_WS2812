#include "ledfilters.h"

//extern ws2812_hsv_t hsv_buffer[];
extern uint32_t cfg_updated;

#pragma region ������� ������� �� ������ � ���������

uint32_t ledFilter_GetRandom(void)
{
	static uint64_t state0 = 1;
	static uint64_t state1 = 2;
	uint64_t s1 = state0;
	uint64_t s0 = state1;

	state0 = s0;
	s1 ^= s1 << 23;
	s1 ^= s1 >> 17;
	s1 ^= s0;
	s1 ^= s0 >> 26;
	state1 = s1;

	return (uint32_t)(state0 + state1);
}

strip_state_t ledFilter_GetRandomAllowed(void)
{
	if (ledFilter_GetRandom() < 30000)
	{
		return state_fade;
	}
	return state_rainbow;
}


void ledFilter_Deinit(struct led_filter *filter)
{
    void *priv;

    if(filter->priv != NULL)
	{
        priv = filter->priv;
        filter->priv = NULL;
        free(priv);
    }
    filter->filter = NULL;
    filter->name = NULL;
    filter->init = NULL;
}

int32_t ledFilter_InitHandler(strip_handler_t *this, ledfilters_cfg_t *cfg, ws2812_t *ws2812, bool update)
{
    struct led_filter *filter;
    int result = 1;

    if(cfg->magic != LEDFILTERS_CFG_CHECKWORD)
	{
        memset(cfg, 0xff, sizeof(cfg));
        cfg->magic = LEDFILTERS_CFG_CHECKWORD;
        cfg->strip_len = DEF_STRIP_LEN;
        cfg->delay = 10;
        cfg->brightness = MAX_STRIP_BRIGHT;

        cfg_updated = 1;
    }

    if(cfg->strip_len > MAX_STRIP_LEN)
	{
        cfg->strip_len = MAX_STRIP_LEN;
        cfg_updated = 1;
    }

    if(cfg->delay > MAX_STRIP_DELAY)
	{
        cfg->delay = MAX_STRIP_DELAY;
        cfg_updated = 1;
    }

    if(cfg->brightness > MAX_STRIP_BRIGHT)
	{
        cfg->brightness = MAX_STRIP_BRIGHT;
        cfg_updated = 1;
    }
    
    if(!update)
	{
        INIT_LIST_HEAD(&this->filters);
        this->state = state_rainbow;
    }

    this->strip_len = cfg->strip_len;
    this->delay = cfg->delay;
    this->brightness = cfg->brightness;
    this->hsv_vals = malloc(sizeof(ws2812_hsv_t) * cfg->strip_len);
	if (this->hsv_vals == NULL)
	{
		printf("[%s] malloc() failed\n", __func__);
		result = -1;
		goto err_out;
	}

	memset(this->hsv_vals, 0x0, sizeof(ctx_rainbow_t) * cfg->strip_len);

	ws2812_SetLen(ws2812, this->strip_len);

    if(update)
	{
        list_for_each_entry(filter, &this->filters, filters, struct led_filter)
		{
            result = filter->init(filter, cfg, true);
            if(result != 0)
			{
                printf("[%s] updating filter %s failed.\n", __func__, filter->name != NULL ? filter->name : "unknown");
                goto err_out;
            }
        }
    }

err_out:
    return result;
}

#pragma endregion

#pragma region Rainbow

int32_t ledFilter_InitRainbow(struct led_filter *this, ledfilters_cfg_t *cfg, bool update)
{
	int32_t result = 1;
	ctx_rainbow_t *ctx;

	if (update)
	{
		ctx = (ctx_rainbow_t *) this->priv;
	}
	else
	{
		this->name = "rainbow";
		this->filter = ledFilter_Rainbow;
		this->init = ledFilter_InitRainbow;
		this->deinit = ledFilter_Deinit;
		INIT_LIST_HEAD(&(this->filters));

		ctx = malloc(sizeof(ctx_rainbow_t));
		if (ctx == NULL)
		{
			printf("[%s] malloc() failed\n", __func__);
			result = -1;
			goto err_out;
		}

		memset(ctx, 0x0, sizeof(ctx_rainbow_t));
		this->priv = ctx;
	}


	if (cfg->rainbow.valid == 0x0)
	{
		cfg->rainbow.valid = 1;
		cfg->rainbow.hue_min = 0;
		cfg->rainbow.hue_max = 255;
		cfg->rainbow.hue_steps = 10; // �� ������� ����������� �������� ��� ������
		cfg->rainbow.cycle_steps = 255;

		cfg_updated = 1;
	}

	if (cfg->rainbow.hue_max <= cfg->rainbow.hue_min)
	{
		cfg->rainbow.hue_max = cfg->rainbow.hue_min;
		ctx->hue_step = 0u;
		ctx->cycle_step = 0u;
		cfg_updated = 1;
	}

	ctx->hue_min = scale_up(cfg->rainbow.hue_min);
	ctx->hue_max = scale_up(cfg->rainbow.hue_max);

	if (ctx->hue_min != ctx->hue_max)
	{
		if (cfg->rainbow.hue_steps > 0)
		{
			ctx->hue_step = (ctx->hue_max - ctx->hue_min) / cfg->rainbow.hue_steps;
		}
		if (cfg->rainbow.cycle_steps > 0)
		{
			ctx->cycle_step = (ctx->hue_max - ctx->hue_min) / cfg->rainbow.cycle_steps;
		}
	}

	ctx->curr_hue = min(ctx->curr_hue, ctx->hue_max);
	ctx->curr_hue = max(ctx->curr_hue, ctx->hue_min);

err_out:
	return result;
}


void ledFilter_Rainbow(struct led_filter *this, strip_handler_t *strip)
{
	int32_t i;
	ws2812_hsv_t tmp_hsv;
	uint32_t tmp_hue;
	ctx_rainbow_t *ctx;

	ctx = (ctx_rainbow_t *) this->priv;

	if (strip->state != state_rainbow) return;

	tmp_hue = ctx->curr_hue;
	tmp_hsv.sat = 255;
	tmp_hsv.value = MAX_STRIP_BRIGHT;

	for (i = 0; i < strip->strip_len; i++)
	{
		tmp_hsv.hue = scale_down(tmp_hue);
		strip->hsv_vals[i] = tmp_hsv;

		tmp_hue += ctx->hue_step;
		if (ctx->hue_min == 0 && ctx->hue_max == scale_up(255u))
		{
			tmp_hue %= scale_up(256);
		}
		else
		{
			if (tmp_hue > ctx->hue_max)
			{
				tmp_hue = ctx->hue_max;
				ctx->hue_step = -ctx->hue_step;
			}
			else if (tmp_hue < ctx->hue_min)
			{
				tmp_hue = ctx->hue_min;
				ctx->hue_step = -ctx->hue_step;
			}
		}
	}

	ctx->curr_hue += ctx->cycle_step;
	if (ctx->hue_min == 0 && ctx->hue_max == scale_up(255u))
	{
		ctx->curr_hue %= scale_up(256);
	}
	else
	{
		if (ctx->curr_hue > ctx->hue_max)
		{
			ctx->curr_hue = ctx->hue_max;
			ctx->cycle_step = -ctx->cycle_step;
		}
		else if (ctx->curr_hue < ctx->hue_min)
		{
			ctx->curr_hue = ctx->hue_min;
			ctx->cycle_step = -ctx->cycle_step;
		}
	}
}
#pragma endregion

#pragma region Fade

int32_t ledFilter_InitFade(struct led_filter *this, ledfilters_cfg_t *cfg, bool update)
{
	int32_t result = 1;
	ctx_fade_t *ctx;

	if (update)
	{
		ctx = (ctx_fade_t *) this->priv;
	}
	else
	{
		ctx = malloc(sizeof(ctx_fade_t));

		this->name = "fade";
		this->priv = ctx;
		this->filter = ledFilter_Fade;
		this->init = ledFilter_InitFade;
		this->deinit = ledFilter_Deinit;
		INIT_LIST_HEAD(&(this->filters));

		if (ctx == NULL)
		{
			printf("[%s] malloc() failed\n", __func__);
			result = -1;
			goto err_out;
		}

		memset(ctx, 0x0, sizeof(*ctx));
		this->priv = ctx;
	}

	if (cfg->fade.valid == 0x0)
	{
		cfg->fade.valid = 1;
		cfg->fade.min = 0u;
		cfg->fade.max = 255u;
		cfg->fade.steps = LEDFILTERS_MAX_STEPS;
		cfg_updated = 1;
	}

	ctx->min = scale_up(cfg->fade.min);
	ctx->max = scale_up(cfg->fade.max);
	/*
	if (cfg->fade.min >= cfg->fade.max)
	{
		cfg->fade.max = cfg->fade.min;
		cfg_updated = 1;
	}
	else
	{
		if (cfg->fade.steps > 0)
		{
			if (ctx->curr_step < 0)
			{
				ctx->curr_step = -(int32_t)((ctx->max - ctx->min) / cfg->fade.steps);
			}
			else
			{
				ctx->curr_step = (ctx->max - ctx->min) / cfg->fade.steps;
			}
		}
		
	}
	

	ctx->curr_val = max(ctx->curr_val, ctx->min);
	ctx->curr_val = min(ctx->curr_val, ctx->max);
	*/
	ctx->curr_val = 0;
	ctx->curr_step = 0;

err_out:
	return result;
}

void ledFilter_Fade(struct led_filter *this, strip_handler_t *strip)
{
    int i;
    ctx_fade_t *ctx;

    ctx = (ctx_fade_t *) this->priv;

	if (strip->state != state_fade) return;

	if (ctx->curr_val)
	{
		for (i = 0; i < strip->strip_len; i++)
		{
			if (strip->hsv_vals[i].value > (255 / LEDFILTERS_MAX_STEPS))
				strip->hsv_vals[i].value -= (255 / LEDFILTERS_MAX_STEPS);// scale_down(ctx->curr_val);
			else
				strip->hsv_vals[i].value = 0;
		}
	}
	else
	{
		for (i = 0; i < strip->strip_len; i++)
		{
			if (strip->hsv_vals[i].value < (MAX_STRIP_BRIGHT / LEDFILTERS_MAX_STEPS))
				strip->hsv_vals[i].value += (MAX_STRIP_BRIGHT / LEDFILTERS_MAX_STEPS);
			else
				strip->hsv_vals[i].value = MAX_STRIP_BRIGHT;
		}
	}
	ctx->curr_step++;

	if (ctx->curr_step >= LEDFILTERS_MAX_STEPS)
	{
		ctx->curr_val = !ctx->curr_val;
		ctx->curr_step = 0;
	}
	/*
    if(ctx->curr_step == 0)
	{
        return;
    }

    ctx->curr_val += ctx->curr_step;

    if(ctx->curr_val <= ctx->min)
	{
        ctx->curr_step = -ctx->curr_step;
        ctx->curr_val = ctx->min;
    } 
	else if(ctx->curr_val >= ctx->max)
	{
        ctx->curr_step =  -ctx->curr_step;
        ctx->curr_val = ctx->max;
    }
	*/



}

#pragma endregion

#pragma region Flicker
int32_t ledFilter_InitFlicker(struct led_filter *this, ledfilters_cfg_t *cfg, bool update)
{
	int32_t result = 1;
	ctx_flicker_t *ctx;

	if (update)
	{
		ctx = (ctx_flicker_t *)this->priv;
	}
	else
	{
		this->name = "flicker";
		this->filter = ledFilter_Flicker;
		this->init = ledFilter_InitFlicker;
		this->deinit = ledFilter_Deinit;
		INIT_LIST_HEAD(&(this->filters));

		ctx = malloc(sizeof(*ctx));
		if (ctx == NULL)
		{
			printf("[%s] malloc() failed\n", __func__);
			result = -1;
			goto err_out;
		}

		memset(ctx, 0x0, sizeof(*ctx));
		this->priv = ctx;
	}

	if (cfg->flicker.valid == 0x0)
	{
		cfg->flicker.valid = 1;
		cfg->flicker.rate = 100;
		cfg_updated = 1;
	}

	ctx->next_off = 200;
	ctx->next_on = 0;
	ctx->off_delay = 200;
	ctx->on_delay = 40;

err_out:
	return result;
}

void ledFilter_Flicker(struct led_filter *this, strip_handler_t *strip)
{
	int32_t i;
    ctx_flicker_t *ctx;
	ctx = (ctx_flicker_t *) this->priv;

	if (strip->state != state_flicker) return;

    if(ctx->next_off > 0)
	{
        --(ctx->next_off);
        if(ctx->next_off == 0)
		{
            do
			{
                ctx->next_on = ledFilter_GetRandom() % ctx->on_delay;
            }
			while(ctx->next_on == 0);
        }
    }

    if(ctx->next_off == 0)
	{
        for(i = 0; i < strip->strip_len; ++i)
		{
			strip->hsv_vals[i].value = 0;
        }
    }

    if(ctx->next_on > 0)
	{
        --(ctx->next_on);
        if(ctx->next_on == 0)
		{
            ctx->off_delay /= 2;
            if(ctx->off_delay <= 1)
			{
                ctx->next_off = 200;
                ctx->next_on = 0;
                ctx->off_delay = 200;
                ctx->on_delay = 40;
                ctx->active = 0;
				//strip->state = state_eye;
            }
			else
			{
				do
				{
                    ctx->next_off = ledFilter_GetRandom() % ctx->off_delay;
                }
				while(ctx->next_off == 0);
            }
        }
    }
}
#pragma endregion

#pragma region Eye
int32_t ledFilter_InitEye(struct led_filter *this, ledfilters_cfg_t *cfg, bool update)
{
	int32_t result = 1;
	ctx_eye_t *ctx;

	if (update)
	{
		ctx = (ctx_eye_t *) this->priv;
	}
	else
	{
		this->name = "Eye";
		this->filter = ledFilter_Eye;
		this->init = ledFilter_InitEye;
		this->deinit = ledFilter_Deinit;
		INIT_LIST_HEAD(&(this->filters));

		ctx = malloc(sizeof(*ctx));
		if (ctx == NULL)
		{
			printf("[%s] malloc() failed\n", __func__);
			result = -1;
			goto err_out;
		}

		memset(ctx, 0x0, sizeof(*ctx));
		this->priv = ctx;

		ctx->state = eye_init;
		ctx->wait = 100;
		ctx->updates = 0;
	}

	if (cfg->eye.valid != 1)
	{
		cfg->eye.valid = 1;
		cfg->eye.rate = 10;
		cfg_updated = 1;
	}

	if (cfg->eye.rate != 0)
	{
		ctx->curr_pos = scale_up(cfg->strip_len / 2);
		ctx->rate = 100 / cfg->eye.rate;
	}
	else
	{
		ctx->rate = 0;
	}

err_out:
	return result;
}


void ledFilter_Eye(struct led_filter *this, strip_handler_t *strip)
{
	int32_t i, jump;
    ctx_eye_t *ctx;

    ctx = (ctx_eye_t *) this->priv;
	/*
    if(ctx->rate == 0)
	{
        *state = state_rainbow;
        return;
    }

    if(state != state_eye)
	{
        if(state != state_flicker)
		{
            ++ctx->updates;
            if(ctx->updates >= strip_len)
			{
                ctx->updates = 0;
                if(ledfilter_GetRandom() % ctx->rate == 0)
				{
                    state = state_flicker;
                }
            }
        }

        return;
    }
	*/

    switch (ctx->state) 
	{
    case eye_init:
        ctx->brightness = scale_up(127u);
        ctx->tmp_floor = 0;
        ctx->tmp_peak = scale_up(8u);
        ctx->inc = ctx->tmp_peak / 16;
        ctx->level = 0;
        ctx->target_pos = scale_down(ctx->curr_pos);
        ctx->state = eye_waking;
        ctx->jumps = 5 + ledFilter_GetRandom() % 10;
        ctx->jump_len = strip->strip_len / 2;
        ctx->curr_speed = 1;
        ctx->wait = 60;
        // no break
    case eye_waking:
        if(ctx->level >= ctx->brightness)
		{
            ctx->state = eye_searching;
            ctx->wait = 200;
        }
		else
		{
            ctx->level += ctx->inc;
            if(ctx->level >= ctx->tmp_peak)
			{
                ctx->inc = -ctx->inc;
            }
			else if(ctx->inc < 0 && ctx->level <= ctx->tmp_floor)
			{
                ctx->level = ctx->tmp_floor;
                ctx->tmp_floor = ctx->tmp_peak;
                ctx->tmp_peak *= 2;
                ctx->tmp_peak = min(ctx->tmp_peak, ctx->brightness);
                ctx->inc = (ctx->tmp_peak - ctx->tmp_floor) / 96;
            }
        }
        ctx->level = min(ctx->level, ctx->brightness);
        break;
    case eye_searching:
        if(scale_down(ctx->curr_pos) > ctx->target_pos)
		{
            ctx->curr_pos -= ctx->curr_speed;
            ctx->curr_speed = min(ctx->curr_pos - scale_up(ctx->target_pos), ctx->curr_speed + 1);
        }
		else if(scale_down(ctx->curr_pos) < ctx->target_pos)
		{
            ctx->curr_pos += ctx->curr_speed;
            ctx->curr_speed = min(scale_up(ctx->target_pos) -
                                ctx->curr_pos, ctx->curr_speed + 1);
        }
		else
		{
            if(ctx->wait == 0)
			{
                if(ctx->jumps > 0)
				{
                    --ctx->jumps;
                    jump = 2 + ledFilter_GetRandom() % (1 + ctx->jump_len);
                    ctx->jump_len /= 2;
                    if(ledFilter_GetRandom() % 2)
					{
                        jump = -jump;
                    }
                    if((ctx->target_pos + jump) < 2 || (ctx->target_pos + jump) >= (strip->strip_len - 2))
					{
                        jump = -jump;
                    }
                    ctx->target_pos += jump;
                    ctx->curr_speed = scale_up(1);
                    ctx->wait = 10 + ledFilter_GetRandom() % 10;
                }
				else
				{
                    ctx->state = eye_found;
                    ctx->wait = 100;
                }
            }
			else
			{
                --ctx->wait;
            }
        }
        break;
    case eye_found:
        if(ctx->wait == 0)
		{
            ctx->state = eye_hiding;
            ctx->wait = 100;
        }
		else
		{
            --ctx->wait;
        }
        break;
    case eye_hiding:
        if(ctx->level <= scale_up(1u))
		{
            ctx->state = eye_sleeping;
            ctx->wait = 100;
        }
		else
		{
            ctx->level -= scale_up(1u);
        }
        break;
    case eye_sleeping:
        if(ctx->wait == 0)
		{
            ctx->state = eye_init;
			//strip->state = state_rainbow;
        }
		else
		{
            --ctx->wait;
        }
    }

    if(ctx->state != eye_sleeping)
	{
        uint32_t pos;

        for(i = 0;i < strip->strip_len;++i)
		{
			strip->hsv_vals[i].value = 0;
        }

        pos = max(scale_down(ctx->curr_pos), 2);
        pos = min(pos, strip->strip_len - 2);

		strip->hsv_vals[pos].hue++;// = 0;
		strip->hsv_vals[pos].sat = 255;
		strip->hsv_vals[pos].value = (uint8_t) scale_down(ctx->level);

		strip->hsv_vals[pos - 1] = strip->hsv_vals[pos];
		strip->hsv_vals[pos - 1].value = strip->hsv_vals[pos].value / 4;
		strip->hsv_vals[pos + 1] = strip->hsv_vals[pos];
		strip->hsv_vals[pos + 1].value = strip->hsv_vals[pos].value / 4;

    }
}
#pragma endregion
