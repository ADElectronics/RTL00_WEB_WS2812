#ifndef _LEDFILTERS_H_
#define _LEDFILTERS_H_

#include <math.h>
#include <stdint.h>
#include <stdbool.h>
#include "macro_common.h"
#include "dlist.h"
#include <autoconf.h>
#include <platform_opts.h>
#include <platform_stdlib.h>
#include "device_lock.h"
#include "ws2812.h"

#define LEDFILTERS_CFG_CHECKWORD   0x4C414D50 // "LAMP"
#define LEDFILTERS_MAX_STEPS   100

#define DEF_STRIP_LEN       WS2812_LEDS_MAX
#define MAX_STRIP_LEN       WS2812_LEDS_MAX
#define MAX_STRIP_BRIGHT    100
#define MAX_STRIP_DELAY     100

#pragma region Rainbow
typedef struct __attribute__((packed))
{
    uint32_t valid;
    uint32_t hue_min;
    uint32_t hue_max;
    uint32_t hue_steps;
    uint32_t cycle_steps;
} cfg_rainbow_t;

typedef struct
{
	int32_t hue_min;
	int32_t hue_max;
	int32_t hue_step;
	int32_t cycle_step;
	int32_t curr_hue;
} ctx_rainbow_t;
#pragma endregion

#pragma region Fade
typedef struct __attribute__((packed))
{
    uint32_t valid;
    uint32_t min;
    uint32_t max;
    uint32_t steps;
} cfg_fade_t;

typedef struct
{
	int32_t min;
	int32_t max;
	int32_t curr_val;
	int32_t curr_step;
} ctx_fade_t;
#pragma endregion

#pragma region Flicker
typedef struct __attribute__((packed))
{
    uint32_t valid;
    uint32_t rate;
} cfg_flicker_t;

typedef struct
{
	uint32_t rate;
	unsigned int active;

	unsigned int off_delay;
	unsigned int on_delay;
	unsigned int next_off;
	unsigned int next_on;
} ctx_flicker_t;
#pragma endregion

#pragma region Eye
typedef struct __attribute__((packed))
{
    uint32_t valid;
    uint32_t rate;
} cfg_eye_t;

typedef enum
{
	eye_init, 
	eye_waking, 
	eye_searching, 
	eye_found, 
	eye_hiding, 
	eye_sleeping
} eye_state;

typedef struct
{
	eye_state state;
	uint32_t rate;
	uint32_t brightness;
	int32_t inc;
	int32_t tmp_peak;
	int32_t tmp_floor;
	uint32_t level;
	uint32_t curr_speed;
	uint32_t curr_pos;
	uint32_t target_pos;
	uint32_t jump_len;
	uint32_t jumps;
	uint32_t wait;
	uint32_t updates;
} ctx_eye_t;
#pragma endregion

typedef enum
{
	state_rainbow = 0,
	state_flicker,
	state_fade,
	state_eye,
} strip_state_t;

typedef struct
{
	strip_state_t state;
	struct list_head filters;
	ws2812_hsv_t *hsv_vals;
	volatile size_t strip_len;
	volatile uint32_t brightness;
	volatile uint32_t delay;
} strip_handler_t;

typedef struct __attribute__((packed))
{
    uint32_t magic;
    uint32_t strip_len;
    uint32_t delay; 
    uint32_t brightness;

    cfg_rainbow_t rainbow;
    cfg_fade_t    fade;
    cfg_flicker_t flicker;
    cfg_eye_t     eye;
} ledfilters_cfg_t;

struct led_filter;
typedef void(*filter_func)(struct led_filter *lf, strip_handler_t *);
typedef int32_t(*init_func)(struct led_filter *lf, ledfilters_cfg_t *cfg, bool update);
typedef void(*deinit_func)(struct led_filter *lf);

struct led_filter
{
	char *name;
	struct list_head filters;
	filter_func filter;
	init_func init;
	deinit_func deinit;
	void *priv;
};

int32_t ledFilter_InitHandler(strip_handler_t *this, ledfilters_cfg_t *cfg, ws2812_t *ws2812, bool update);

int32_t ledFilter_InitRainbow(struct led_filter *this, ledfilters_cfg_t *cfg, bool update);
void ledFilter_Rainbow(struct led_filter *this, strip_handler_t *strip);

int32_t ledFilter_InitFade(struct led_filter *this, ledfilters_cfg_t *cfg, bool update);
void ledFilter_Fade(struct led_filter *this, strip_handler_t *strip);

int32_t ledFilter_InitFlicker(struct led_filter *this, ledfilters_cfg_t *cfg, bool update);
void ledFilter_Flicker(struct led_filter *this, strip_handler_t *strip);

int32_t ledFilter_InitEye(struct led_filter *this, ledfilters_cfg_t *cfg, bool update);
void ledFilter_Eye(struct led_filter *this, strip_handler_t *strip);

void ledFilter_Deinit(struct led_filter *filter);

strip_state_t ledFilter_GetRandomAllowed(void);

#endif // _LEDFILTERS_H_
