#include "ledeffectsserver.h"
#include "ws2812.h"
#include "dlist.h"
#include <flash_api.h>

volatile uint32_t cfg_updated = 0;

ws2812_t *ws2812_cfg = NULL;
strip_handler_t strip; 
ledfilters_cfg_t strip_cfg;
//ws2812_hsv_t hsv_buffer[WS2812_LEDS_MAX];

SemaphoreHandle_t cfg_sema = NULL;

void ledEffectsServer_Init()
{
	struct led_filter rainbow;
	struct led_filter fade;
	struct led_filter flicker;
	struct led_filter eye;
	struct led_filter *filter;
	//strip_state_t state;
	//BaseType_t status;

	//ledEffectsServer_LoadConfigFromFlash();

	cfg_sema = xSemaphoreCreateMutex();

	ws2812_cfg = ws2812_Init(WS2812_LEDS_MAX);
	if (ws2812_cfg == NULL)
	{
		printf("[%s] ws2812_Init() failed\n", __func__);
		goto error;
	}

	if (!ledFilter_InitHandler(&strip, &strip_cfg, ws2812_cfg, false))
	{
		printf("[%s] ledFilter_InitHandler() failed\n", __func__);
		goto error;
	}

	if (!ledFilter_InitRainbow(&rainbow, &strip_cfg, false))
	{
		printf("[%s] ledFilter_InitRainbow() failed\n", __func__);
		goto error;
	}
	list_add_tail(&(rainbow.filters), &(strip.filters));

	if (!ledFilter_InitFade(&fade, &strip_cfg, false))
	{
		printf("[%s] ledFilter_InitFade() failed\n", __func__);
		goto error;
	}
	list_add_tail(&(fade.filters), &(strip.filters));

	if (!ledFilter_InitFlicker(&flicker, &strip_cfg, false))
	{
		printf("[%s] ledFilter_InitFlicker() failed\n", __func__);
		goto error;
	}
	//list_add_tail(&(flicker.filters), &(strip.filters));

	if (!ledFilter_InitEye(&eye, &strip_cfg, false))
	{
		printf("[%s] ledFilter_InitEye() failed\n", __func__);
		goto error;
	}
	//list_add_tail(&(eye.filters), &(strip.filters));

	//if (cfg_updated != 0)
	//{
		// save_config();
	//}
	strip.state = state_rainbow;// ledFilter_GetRandomAllowed();
	while (1)
	{
		if(xSemaphoreTake(cfg_sema, 5 * configTICK_RATE_HZ))
		{
			list_for_each_entry(filter, &strip.filters, filters, struct led_filter)
			{
				filter->filter(filter, &strip);
			}

			ws2812_Update(ws2812_cfg, strip.hsv_vals, strip.strip_len, strip.delay);

			strip.state = state_fade;// ledFilter_GetRandomAllowed();

			xSemaphoreGive(cfg_sema);
		}
	}

error:
	while (1)
	{
		vTaskDelay(1000);
	}
}




void ledEffectsServer_LoadConfigFromFlash()
{
	flash_t flash;

	printf("[%s] reading config from flash\n", __func__);
	device_mutex_lock(RT_DEV_LOCK_FLASH);
	flash_stream_read(&flash, LED_SETTINGS_SECTOR, sizeof(strip_cfg), (uint8_t *)&strip_cfg);
	device_mutex_unlock(RT_DEV_LOCK_FLASH);
}

void ledEffectsServer_SaveConfigToFlash()
{
	flash_t flash;

	printf("[%s] saving config to flash\n", __func__);

	cfg_updated = 0;

	device_mutex_lock(RT_DEV_LOCK_FLASH);
	flash_erase_sector(&flash, LED_SETTINGS_SECTOR);
	flash_stream_write(&flash, LED_SETTINGS_SECTOR, sizeof(strip_cfg), (uint8_t *)&strip_cfg);
	device_mutex_unlock(RT_DEV_LOCK_FLASH);
}

/*
struct blinken_cfg *blinken_get_config(void)
{
blinken_cfg_t *cfg = NULL;

if(strip_cfg.magic == BLINKEN_CFG_MAGIC)
{
cfg = malloc(sizeof(*cfg));
if(cfg != NULL)
{
memmove(cfg, &strip_cfg, sizeof(*cfg));
}
}

return cfg;
}


int blinken_set_config(blinken_cfg_t *cfg)
{
int result;
BaseType_t status;

result = 0;
if(cfg == NULL || cfg->magic != BLINKEN_CFG_MAGIC)
{
result = -1;
goto error;
}

status = xSemaphoreTake(cfg_sema, 15 * configTICK_RATE_HZ);
if(status != pdTRUE)
{
printf("[%s] Timeout waiting for config sema.\n", __func__);
result = -1;
goto error;
}

result = init_handler(&handler, cfg, ws2812_cfg, true);
if(result == 0)
{
memmove(&strip_cfg, cfg, sizeof(strip_cfg));
save_config();
}

xSemaphoreGive(cfg_sema);

error:
return result;
}
*/


